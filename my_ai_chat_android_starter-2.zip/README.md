# My AI Assistant — Android-ready starter

This starter contains a responsive chat website and a Node.js backend. The backend keeps the OpenAI API key on the server; the browser/Android app never receives it.

## Before you start
- You need an API key from your AI provider account. API usage may cost money and is separate from a ChatGPT subscription. Set a usage limit in the provider dashboard.
- A free host can have sleep/wake delays and usage limits. Render documents these limitations at https://render.com/docs/free.
- Do not publish your `.env` file or API key in source code, screenshots, or a public repository.

## Run locally (computer with Node.js 18+)
1. Extract the ZIP.
2. Copy `.env.example` to `.env`.
3. Put your key after `OPENAI_API_KEY=` in `.env`.
4. Open a terminal in this folder and run:
   ```bash
   npm install
   npm start
   ```
5. Open `http://localhost:3000`.

## Deploy the backend and website for free testing on Render
1. Create a Git repository and upload these files (do not upload `.env`; `.gitignore` excludes it).
2. Sign in to Render and choose **New → Web Service**, then connect the repository.
3. Set **Build Command** to `npm install`.
4. Set **Start Command** to `npm start`.
5. Choose the Free instance if available.
6. In the service's Environment settings, add:
   - `OPENAI_API_KEY` = your private API key
   - `OPENAI_MODEL` = a model available to your API account (default is `gpt-4.1-mini`)
7. Deploy and open the `https://...onrender.com` URL. Test a message.
8. If the service sleeps, the first request after inactivity can be slow. See Render's current free-plan limits.

## Turn it into an Android APK
### Easiest phone-friendly route: WebView wrapper service
1. First deploy and test the website above so you have a working HTTPS URL.
2. Use a reputable website-to-Android WebView wrapper service you trust.
3. Enter your HTTPS website URL, app name, and icon, then build/download the APK.
4. Test on your phone. The app needs internet access because the AI runs online.

### Android Studio route
Create an Android project with an Activity containing a WebView that loads your deployed HTTPS URL. Enable JavaScript only for your own trusted site, enable internet permission, and do not add the AI API key to Android code. For a distributable app, also implement back navigation, offline/error handling, and safe navigation restrictions.

## Troubleshooting
- `The server owner has not configured...`: add `OPENAI_API_KEY` in Render Environment settings and redeploy/restart.
- AI service error: check the API key, model access, account billing/usage limits, and Render logs.
- Slow first response: free web services may sleep while idle.
- API key safety: rotate the key immediately if it is accidentally exposed.
- The chat is stateless: it sends the current message only; conversation memory and sign-in are not included in this starter.

## Included security basics
- API key stored only as a server environment variable
- Request body size limit
- Per-IP rate limit on chat requests
- Helmet security headers
- Input length validation
- No database or login system included
